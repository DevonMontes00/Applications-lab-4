package application.model;

public class Appointment {
	private String name, doctor, date, time;

	public Appointment(String name, String doctor, String date, String time) {
		super();
		this.name = name;
		this.doctor = doctor;
		this.date = date;
		this.time = time;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDoctor() {
		return doctor;
	}
	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return name + " " + doctor + " " + date + " " + time;
	}
	
	
	
	
	
}
