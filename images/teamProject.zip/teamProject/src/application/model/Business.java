package application.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Business {
	private String BusinessName;
	private String Occupation;
	private String RegisterCode;
	private ArrayList<Employee> Employees;
	private ArrayList<User> users;
	
	public Business(String businessName, String registerCode, String occupation) {
		super();
		BusinessName = businessName;
		Employees = new ArrayList<Employee>();
		users = new ArrayList<User>();
		Occupation = occupation;
		RegisterCode = registerCode;
	}

	public String getBuisnessName() {
		return BusinessName;
	}
	
	public void setBuisnessName(String businessName) {
		BusinessName = businessName;
	}
	
	public String getOccupation() {
		return Occupation;
	}
	
	public void setOccupation(String occupation) {
		Occupation = occupation;
	}
	
	public String getRegisterCode() {
		return RegisterCode;
	}
	
	public void setRegisterCode(String registerCode) {
		RegisterCode = registerCode;
	}
		
	public void removeEmployee(Employee x) {
		Employees.remove(x);
	}
	
	public String toString(){       
        String list = "";
       
        for(int i = 0; i < Employees.size(); i++) {
        	list += Employees.get(i) + " \n";
        }
        return BusinessName + " " + Occupation + " " + RegisterCode + "\n\n" + list;
    }
	
	public ArrayList<Employee> getEmployees() {
		return Employees;
	}
	
	public void loadUsers(String fileName){
		try {
    		File file = new File (fileName);
    		Scanner scan = new Scanner( file );
	
    		while( scan.hasNext()) {
    			String line = scan.nextLine();				
        		String[] values = line.split(",");
        		User x = new User(values[0], values[1], values[2]);
        		users.add(x);
    		}
    		scan.close();
    	}
    	catch( IOException e ) {
			System.out.println( "Error loading the file - please check its location." );
			e.printStackTrace(); 
		}
	}
	
	public void loadEmployees(String fileName) {
    	try {
    		File file = new File (fileName);
    		Scanner scan = new Scanner( file );
	
    		while( scan.hasNext()) {
    			String line = scan.nextLine();				
        		String[] values = line.split(",");
        		Employee x = new Employee(values[0], values[1], values[2], values[3], values[4], values[5], values[6], values[7]);	
        		Employees.add(x);
    		}
    		scan.close();
    	}
    	catch( IOException e ) {
			System.out.println( "Error loading the file - please check its location." );
			e.printStackTrace(); 
		}
    }
	
	public void loadAppointments(String fileName) {
		try {
    		File file = new File (fileName);
    		Scanner scan = new Scanner( file );
	
    		while( scan.hasNext()) {
    			String line = scan.nextLine();
        		String[] values = line.split(",");
        		
        		Appointment x = new Appointment(values[0],values[1], values[2], values[3]);
        		
        		for(int i = 0; i < Employees.size(); i++) {
        			if(values[1].equals(Employees.get(i).getName())){
        				Employees.get(i).addAppointment(x);	
        			}
        		}
    		}
    		scan.close();
    	}
    	catch( IOException e ) {
			System.out.println( "Error loading the file - please check its location." );
			e.printStackTrace(); 
		}
    }
	
	public void loadClients(String fileName) {
		try {
    		File file = new File (fileName);
    		Scanner scan = new Scanner( file );
	
    		while( scan.hasNext()) {
    			String line = scan.nextLine();
        		String[] values = line.split(",");
        		Client x = new Client(values[0], values[1], values[2], values[3], values[4]);
        		
        		for(int i = 0; i < Employees.size(); i++) {
        			//if(values[4].equals(Employees.get(i).getName())){
        				Employees.get(i).addClient(x);	
        			//}
        		}
    		}
    		scan.close();
    	}
    	catch( IOException e ) {
			System.out.println( "Error loading the file - please check its location." );
			e.printStackTrace(); 
		}
    }
	
	public void deleteAppoitment(String clientName) {	
		try {
			String name = "";
			String doctor = "";
			String date = "";
			String time = "";
			
			File output = new File("appointments.csv");
			FileWriter writer = new FileWriter(output);
			
			for(int i = 0; i < Employees.size(); i++){
	    		for(int j = 0; j < Employees.get(i).getAppointments().size(); j++) {
	    			Appointment x = Employees.get(i).getAppointments().get(j);
	  
	    			name = x.getName();
	    			doctor = x.getDoctor();
	    			date = x.getDate();
	    			time = x.getTime();
	    			
	    			if ( !clientName.equals(name) ){
	    				writer.write(name + "," + doctor + "," + date + "," + time  + "\n");
	    			}
	    		}
			}
			writer.close();
		}
		catch( IOException e ) {
			System.out.println( "Error loading the file - please check its location." );
			e.printStackTrace(); 
		}
	}
	
	public void addAppoitment(String name, String doctor, String date, String time) {	
		
		try {	
			Appointment x = new Appointment(name, doctor, date, time);
				
			for(int i = 0; i < Employees.size(); i++) {
				for(int j = 0; j < Employees.get(i).getAppointments().size(); j++) {
					String AppDate = Employees.get(i).getAppointments().get(j).getDate();
					String AppTime = Employees.get(i).getAppointments().get(j).getTime();
					
					if (AppDate.equals(x.getDate()) && AppTime.equals(x.getTime())) {
						System.out.println("ERROR: This date and time is already taken.");
						return;
					}
				}
			}
			String open = "";
			String close = "";
			
			for(int n = 0; n < Employees.size(); n++) {
				if( Employees.get(n).getName().equals(doctor)) {
					open = Employees.get(n).getOpenTime();
					close = Employees.get(n).getClosingTime();
				}	
			}
			String[] y = open.split(":");
			String[] w = close.split(":");
			String[] u = time.split(":");
			
			int num = Integer.parseInt(y[0] + y[1]);
			int num2 = Integer.parseInt(w[0] + w[1]);
			int userTime = Integer.parseInt(u[0] + u[1]);
				
			if(num < userTime && userTime < num2 ) {		
				FileWriter fstream = new FileWriter("appointments.csv",true);
				BufferedWriter writer = new BufferedWriter(fstream);
				writer.write(name + "," + doctor + "," + date + "," + time  + "\n");
				writer.close();
			}
			else {
				System.out.print("ERROR: Not in time range");
			}
		}
		catch( IOException e ) {
			System.out.println( "Error loading the file - please check its location." );
			e.printStackTrace(); 
		}
	}
	
	//this function is called from login to create new employee 
	public void addEmployee(String name, String email, String phone, String code, String userName, String password, String openTime, String closingTime) {
		try {
			Employee x = new Employee(name, email, phone, code, userName, password, openTime, closingTime);
			
			for(int i = 0; i < Employees.size(); i++) {
				if(x.getName().equals(Employees.get(i).getName()) && x.getEmail().equals(Employees.get(i).getEmail())) {
					System.out.println("ERROR: This is an existing employee.");
					return;
				}
			}
			FileWriter fstream = new FileWriter("employees.csv",true);
			BufferedWriter writer = new BufferedWriter(fstream);
			writer.write(name +"," + email + "," + phone + "," + code + "," + userName + "," + password + "," + openTime +  "," + closingTime);
			writer.close();
			
			Employees.add(x);
		}
		catch( IOException e ) {
			System.out.println( "Error loading the file - please check its location." );
			e.printStackTrace(); 
		}
	}
	
	public void deleteEmployee(String userName, String password) {
		try {
			String name = "", email = "", phone = "", code = "", username = "", passWord = "", open = "", close = "";
			
			File output = new File("employees.csv");
			FileWriter writer = new FileWriter(output);
			
			for(int i = 0; i < Employees.size(); i++){
				Employee x = Employees.get(i);
				
				name = x.getName();
				email = x.getEmail();
				phone = x.getPhone();
				code = x.getCode();
				username = x.getUserName();
				passWord = x.getUserPass();
				open = x.getOpenTime();
				close = x.getClosingTime();
				
				if ( !userName.equals(username) && !password.equals(passWord) ){
					writer.write(name + "," + email + "," + phone + "," + code + "," + username + "," + passWord + "," + open + "," + close + "\n");
				}
			}
			writer.close();
		}
		catch( IOException e ) {
			System.out.println( "Error loading the file - please check its location." );
			e.printStackTrace(); 
		}	
	}
	
	public void deleteUsername(String username, String password){
		try {
			String Username = "", Password = "", type = "";
			File output = new File("users.csv");
			FileWriter writer = new FileWriter(output);
			
			for(int i = 0; i < users.size(); i++){
				User x = users.get(i);
				Username = x.getUserName();
				Password = x.getPasswd();
				type = x.getLoginType();
				
				if ( Username.equals(username) && Password.equals(password)){
					continue;
				}
				writer.write(Username + "," + Password + "," + type + "\n");
    		}
			writer.close();
		}
		catch( IOException e ) {
			System.out.println( "Error loading the file - please check its location." );
			e.printStackTrace(); 
		}	
	}
}
