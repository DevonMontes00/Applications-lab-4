package application.model;

public class Client {
	private String Name;
	private String Email;
	private String Phone;
	private String BirthDate;
	//private String Doctor;
	//private String AppointmentDate;
	//private String AppointmentTime;
	private String MoreInfo;
	
	public Client(String name, String email, String phone, String birthDate, String moreInfo) {
		super();
		Name = name;
		Email = email;
		Phone = phone;
		BirthDate = birthDate;
		//Doctor = doctor;
		//AppointmentDate = appointmentDate;
		//AppointmentTime = appointmentTime;
		MoreInfo = moreInfo;
	}
	
	public String getMoreInfo() {
		return MoreInfo;
	}

	public void setMoreInfo(String moreInfo) {
		MoreInfo = moreInfo;
	}
/*
	public String getAppointmentDate() {
		return AppointmentDate;
	}

	public void setAppointmentDate(String appointmentDate) {
		AppointmentDate = appointmentDate;
	}

	public String getAppointmentTime() {
		return AppointmentTime;
	}

	public void setAppointmentTime(String appointmentTime) {
		AppointmentTime = appointmentTime;
	}
*/
	public String getName() {
		return Name;
	}
	
	public void setName(String name) {
		Name = name;
	}
	
	public String getEmail() {
		return Email;
	}
	
	public void setEmail(String email) {
		Email = email;
	}
	
	public String getPhone() {
		return Phone;
	}
	
	public void setPhone(String phone) {
		Phone = phone;
	}
	
	public String getBirthDate() {
		return BirthDate;
	}
	
	public void setBirthDate(String birthDate) {
		BirthDate = birthDate;
	}
	/*
	public String getDoctor() {
		return Doctor;
	}
	
	public void setDoctor(String doctor) {
		Doctor = doctor;
	}
	*/
	public String toString() {
		return  "\t" + Name + " " + Email + " " + Phone + " " + MoreInfo;
	}
}
