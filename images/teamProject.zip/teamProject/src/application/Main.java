package application;

import java.io.IOException;

//import application.view.EmployeeController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;


public class Main extends Application {
	public static Stage primaryStage;
	private static AnchorPane loginLayout;
	@Override
	public void start(Stage primaryStage) throws IOException {
		Main.primaryStage = primaryStage;
		Main.primaryStage.setTitle("Bam-Cal");
		showLoginView();
	}
	
	public static void showLoginView() throws IOException{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/Login.fxml"));
		loginLayout = loader.load();
		Scene scene = new Scene(loginLayout);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	public static void showEmployeeView() throws IOException{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/Employee.fxml"));
		//EmployeeController ec = new EmployeeController(userName);
		//loader.setController(ec);
		AnchorPane employeeLayout = loader.load();
		loginLayout.getChildren().setAll(employeeLayout);
	}
	
	public static void showClientView() throws IOException{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/Client.fxml"));
		//ClientController cc = new ClientController(userName);
		//loader.setController(cc);
		AnchorPane clientLayout = loader.load();
		loginLayout.getChildren().setAll(clientLayout);
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}


