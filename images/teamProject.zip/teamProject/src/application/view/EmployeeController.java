package application.view;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.util.ArrayList;
import application.Main;
import application.model.Appointment;
import application.model.Business;
import application.model.Employee;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class EmployeeController implements EventHandler <ActionEvent>{
	@FXML
	private Label title, message, message2;
	@FXML
	private Button logOut, delete;
	@FXML
	private TextField name, name1, doctor, date, time, username, password;
	@FXML
	private ListView<String> list;
	
	public static Business x;
	
	public void initialize(){
		x = new Business("doctors clinic", "6721", "health");
		x.loadEmployees("employees.csv");
		x.loadClients("clients.csv");
		x.loadAppointments("appointments.csv");
		x.loadUsers("users.csv");
		
		String userName = LoginController.username;
		String pass = LoginController.password;
		ArrayList<Employee> Employees = x.getEmployees();
		Employee y = null;
		
		for( int i = 0; i < Employees.size(); i++){
			if( Employees.get(i).getUserName().equals(userName) && Employees.get(i).getUserPass().equals(pass) ){
				y = Employees.get(i);
			}
		}
		list.getItems().add(y.toString());
    }
	
	@FXML
	public void deleteButton(ActionEvent event) {
		String y = name.getText();
		x.deleteAppoitment(y);
		message.setText("Delete Successful");
	
		list.getItems().clear();
		name.clear();
		initialize();
	}
	
	@FXML
	public void addButton(ActionEvent event){
		String name = name1.getText();
		String doc = doctor.getText();
		String appDate = date.getText();
		String appTime = time.getText();
		
		x.addAppoitment(name, doc, appDate, appTime);
		message2.setText("worked");
		System.out.print(name + " " + doc +" " + appDate + " " + appTime);
		
		name1.clear();
		doctor.clear();
		date.clear();
		time.clear();
		list.getItems().clear();
		initialize();
	}
	
	@FXML
	public void terminateButton(){
		String userName = username.getText();
		String Password = password.getText();
		
		x.deleteEmployee(userName, Password);
		
		try {
			x.deleteUsername(userName, Password);
			
			Main.showLoginView();
		} 
		catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	@FXML
	public void logOutButton(ActionEvent e) {
		try {
			Main.showLoginView();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

	@Override
	public void handle(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
