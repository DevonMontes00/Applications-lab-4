package application.view;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.Main;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ClientController implements EventHandler <ActionEvent>, Initializable {
	@FXML
	private Label title;
	
	@FXML
	private Button logOut;
	
	
	public void initialize(URL url, ResourceBundle rb){
		title.setText("Client View");
		// show client info/ all appointments for current client 
    
    }
	
	// button for something
	public void handle(ActionEvent event) {
		
	}
	
	public void logOutButton(ActionEvent e) {
		try {
			Main.showLoginView();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}
